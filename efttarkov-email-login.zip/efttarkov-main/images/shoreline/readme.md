maps shoreline
